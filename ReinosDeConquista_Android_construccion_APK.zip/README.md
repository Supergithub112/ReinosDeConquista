# Reinos de Conquista — Android APK

Proyecto Android nativo, versión 1.0.

## Características
- Estrategia y conquista
- 6 territorios
- Niveles y XP
- Oro e impuestos
- Entrenamiento de tropas
- Dragones desbloqueables desde nivel 3
- Territorios avanzados requieren dragones
- Guardado local aún no implementado

## Generar APK
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Selecciona Build > Build APK(s).
4. La APK de depuración quedará normalmente en:
   app/build/outputs/apk/debug/app-debug.apk

Requisitos: Android Studio reciente con Android SDK 35 y conexión a Internet para la primera sincronización de Gradle.
