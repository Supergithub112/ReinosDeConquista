package com.reinosdeconquista.game;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, stats, map, actions;
    TextView level,gold,troops,dragons,xp,status,territories;
    int lv=1, g=500, tr=100, dr=0, experience=0, owned=0;

    TextView t(String s,int size){
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size);
        v.setTextColor(Color.WHITE); v.setPadding(16,12,16,12); return v;
    }
    Button b(String s){
        Button x=new Button(this); x.setText(s); x.setTextSize(15); x.setAllCaps(false); return x;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b); build(); render();}

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(16,16,16,16); root.setBackgroundColor(Color.rgb(11,16,32));
        ScrollView scroll=new ScrollView(this); scroll.addView(root); setContentView(scroll);

        TextView title=t("🐉 REINOS DE CONQUISTA",24); title.setTextColor(Color.rgb(220,200,255)); root.addView(title);
        TextView sub=t("Estrategia • Conquista • Dragones",15); sub.setTextColor(Color.LTGRAY); root.addView(sub);

        stats=new LinearLayout(this); stats.setOrientation(LinearLayout.VERTICAL); root.addView(stats);
        map=new LinearLayout(this); map.setOrientation(LinearLayout.VERTICAL); root.addView(map);

        root.addView(t("ACCIONES",18));
        actions=new LinearLayout(this); actions.setOrientation(LinearLayout.VERTICAL); root.addView(actions);

        Button train=b("⚔️ Entrenar 10 tropas — 50 oro");
        train.setOnClickListener(v->{if(g>=50){g-=50;tr+=10;msg("Entrenaste 10 tropas.");render();}else msg("No tienes suficiente oro.");});
        actions.addView(train);

        Button dragon=b("🐉 Invocar dragón — 300 oro + nivel 3");
        dragon.setOnClickListener(v->{if(lv<3) msg("Necesitas nivel 3."); else if(g<300) msg("Necesitas 300 de oro."); else {g-=300;dr++;msg("¡Has invocado un dragón!");render();}});
        actions.addView(dragon);

        Button collect=b("💰 Recaudar impuestos");
        collect.setOnClickListener(v->{int r=100+owned*75;g+=r;msg("Recaudaste "+r+" de oro.");render();});
        actions.addView(collect);

        Button reset=b("↻ Reiniciar partida");
        reset.setOnClickListener(v->{lv=1;g=500;tr=100;dr=0;experience=0;owned=0;msg("Partida reiniciada.");render();});
        actions.addView(reset);

        status=t("Selecciona un territorio para atacar.",14); status.setTextColor(Color.LTGRAY); root.addView(status);
    }

    void render(){
        stats.removeAllViews();
        level=t("⭐ Nivel: "+lv,17); gold=t("💰 Oro: "+g,17); troops=t("⚔️ Tropas: "+tr,17);
        dragons=t("🐉 Dragones: "+dr,17); xp=t("✨ XP: "+experience+" / "+(lv*100),17);
        stats.addView(level);stats.addView(gold);stats.addView(troops);stats.addView(dragons);stats.addView(xp);

        map.removeAllViews(); map.addView(t("🗺️ TERRITORIOS",18));
        String[] names={"Aldoria","Nortia","Valoria","Drakos","Imperium","Zandor"};
        for(int i=0;i<6;i++){
            Button q=b((owned>i?"👑 ":"🏰 ")+names[i]+(i>=3?" • Dragón requerido":""));
            final int n=i;
            q.setOnClickListener(v->attack(n,names[n]));
            map.addView(q);
        }
        territories=t("Territorios conquistados: "+owned+"/6",15); map.addView(territories);
    }

    void attack(int n,String name){
        int requiredLevel=1+n/2;
        if(lv<requiredLevel){msg("Necesitas nivel "+requiredLevel+" para atacar "+name+".");return;}
        if(owned>n){msg(name+" ya está bajo tu control.");return;}
        int cost=25+n*15;
        if(tr<cost){msg("Necesitas "+cost+" tropas.");return;}
        if(n>=3 && dr<1){msg("Necesitas al menos 1 dragón para conquistar "+name+".");return;}
        tr-=cost; owned++; g+=100+n*50; gain(60+n*35);
        msg("¡Conquistaste "+name+"! Ganaste oro y XP."); render();
    }

    void gain(int x){experience+=x; while(experience>=lv*100){experience-=lv*100;lv++;g+=150;tr+=25;msg("¡SUBISTE AL NIVEL "+lv+"! +150 oro y +25 tropas.");}}
    void msg(String s){status.setText(s);}
}
